class Question:

    def __init__(self, q_text, answer, category):
        self.text = q_text
        self.answer = answer
        self.category = category